//
//  SpecificCategoryTableViewCell.swift
//  LasVegasTravelApp
//
//  Created by Yaxin Deng on 5/10/20.
//  Copyright © 2020 Yaxin Deng. All rights reserved.
//

import UIKit

class SpecificCategoryTableViewCell: UITableViewCell {

    @IBOutlet weak var imageOutlet: UIImageView!
    
    @IBOutlet weak var descriptionOutlet: UILabel!
    
}
