//
//  CategoryTableViewCell.swift
//  LasVegasTravelApp
//
//  Created by Yaxin Deng on 5/10/20.
//  Copyright © 2020 Yaxin Deng. All rights reserved.
//

import UIKit

class CategoryTableViewCell: UITableViewCell {
    
    @IBOutlet weak var categoryLabelOutlet: UILabel!
    
}
