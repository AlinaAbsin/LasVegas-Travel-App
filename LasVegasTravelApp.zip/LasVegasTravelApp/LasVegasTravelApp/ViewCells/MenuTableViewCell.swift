//
//  MenuTableViewCell.swift
//  LasVegasTravelApp
//
//  Created by Yaxin Deng on 5/9/20.
//  Copyright © 2020 Yaxin Deng. All rights reserved.
//

import UIKit

class MenuTableViewCell: UITableViewCell {

    @IBOutlet weak var typeLabelOutlet: UILabel!
    
}
